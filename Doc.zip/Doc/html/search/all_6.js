var searchData=
[
  ['horario',['Horario',['../class_horario.html',1,'Horario'],['../class_horario.html#a456b3edf2eb01bff63a0cb4eac36dbdd',1,'Horario::Horario()']]]
];
