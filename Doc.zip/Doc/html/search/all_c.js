var searchData=
[
  ['usuario',['Usuario',['../class_usuario.html',1,'Usuario'],['../class_usuario.html#a7f40d14493f834811691e688e8119062',1,'Usuario::Usuario()']]]
];
